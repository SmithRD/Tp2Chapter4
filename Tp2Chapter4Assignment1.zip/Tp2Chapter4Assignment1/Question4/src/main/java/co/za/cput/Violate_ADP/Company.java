package co.za.cput.Violate_ADP;

/**
 *
 */
public class Company {
    private Government buy = new Government();

    public double getMoney()
    {
        return buy.getMoney();
    }
}
