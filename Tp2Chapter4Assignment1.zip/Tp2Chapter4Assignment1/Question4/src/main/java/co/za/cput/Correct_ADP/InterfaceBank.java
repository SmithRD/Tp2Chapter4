package co.za.cput.Correct_ADP;

/**
 *
 */
public interface InterfaceBank {
    double getMoney(double amount);
}
