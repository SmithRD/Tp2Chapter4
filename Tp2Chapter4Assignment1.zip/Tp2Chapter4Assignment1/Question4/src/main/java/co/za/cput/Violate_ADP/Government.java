package co.za.cput.Violate_ADP;

/**
 *
 */
public class Government {

    Parent taxpayer = new Parent(1500);

    public double getMoney()
    {
        return taxpayer.getMoney();
    }
}
