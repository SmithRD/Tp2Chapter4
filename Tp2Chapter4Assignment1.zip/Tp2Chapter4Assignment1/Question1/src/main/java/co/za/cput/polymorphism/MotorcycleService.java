package co.za.cput.polymorphism;

/**
 *
 */
public interface MotorcycleService {
    MotorcycleDomain getMotorcycle();
}
