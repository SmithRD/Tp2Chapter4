package co.za.cput.ISP_Violate;

/**
 *
 */
public interface Person {
    Boolean lectures();
    Boolean studies();
}
