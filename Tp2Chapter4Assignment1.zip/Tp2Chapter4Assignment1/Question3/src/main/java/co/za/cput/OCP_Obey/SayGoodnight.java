package co.za.cput.OCP_Obey;

/**
 *
 */
public interface SayGoodnight {
    String goodnight();
}
