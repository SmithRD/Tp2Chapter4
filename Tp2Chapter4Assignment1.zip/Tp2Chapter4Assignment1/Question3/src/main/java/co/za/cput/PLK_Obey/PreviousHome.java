package co.za.cput.PLK_Obey;

/**
 *
 */
public class PreviousHome {
    private int number;

    PreviousHome(int nm)
    {
        number = nm;
    }

    int getNumber()
    {
        return number;
    }
}
