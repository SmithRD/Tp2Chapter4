package co.za.cput.LSP_Obey;

/**
 *
 */
public class UHDTelevision extends Television{
    @Override
    public boolean isHighDefinition()
    {
        return true;
    }

    @Override
    public boolean is3DCompatible()
    {
        return true;
    }
}
