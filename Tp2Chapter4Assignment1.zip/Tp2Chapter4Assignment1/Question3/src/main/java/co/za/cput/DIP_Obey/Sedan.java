package co.za.cput.DIP_Obey;

/**
 *
 */
public class Sedan implements Car{

    public String getType()
    {
        return "Sedan";
    }

    public String getMake()
    {
        return "BMW";
    }
}
