package co.za.cput.ISP_Obey;

/**
 *
 */
public interface InterfaceStudent {
    Boolean studies();
}
