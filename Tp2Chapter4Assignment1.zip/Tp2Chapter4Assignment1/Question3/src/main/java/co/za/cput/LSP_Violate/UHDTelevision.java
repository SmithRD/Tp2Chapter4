package co.za.cput.LSP_Violate;

/**
 *
 */
public class UHDTelevision extends Television{
    @Override
    public boolean isHighDefinition()
    {
        return super.isHighDefinition();
    }

    @Override
    public boolean is3DCompatible()
    {
        return true;
    }
}
