package co.za.cput.ISP_Obey;

/**
 *
 */
public class Lecturer implements InterfaceLecturer{

    public Boolean teaches() {
        return true;
    }
}
