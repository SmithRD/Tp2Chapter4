package co.za.cput.CRP_Violate;

/**
 *
 */
public class WordFile extends File{
    public Boolean containsWords()
    {
        return true;
    }
}
