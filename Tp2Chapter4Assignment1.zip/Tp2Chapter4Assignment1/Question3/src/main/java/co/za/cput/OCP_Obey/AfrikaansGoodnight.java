package co.za.cput.OCP_Obey;

/**
 *
 */
public class AfrikaansGoodnight implements SayGoodnight {
    public String goodnight(){
        return "Goeie nag";}
    }
