package co.za.cput.CRP_Obey;

/**
 *
 */
public class File {
    Boolean hasSpace() {
        return true;
    }

    Boolean canOpen()
    {
        return true;
    }

    public String getContents(String contains)
    {
        return contains;
    }
}
