package co.za.cput.ISP_Obey;

/**
 *
 */
public class Student implements InterfaceStudent{
    public Boolean studies() {
        return true;
    }

}
