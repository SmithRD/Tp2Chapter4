package co.za.cput.PLK_Violate;

/**
 *
 */
public interface InterfacePerson {
    String getName();
    PreviousHome getPreviousHome();
}
