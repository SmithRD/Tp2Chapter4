package co.za.cput.OCP_Obey;

/**
 *
 */
public class JapaneseGoodnight implements SayGoodnight{
    public String goodnight(){
       return "Oyasuminasai";
    }
}
