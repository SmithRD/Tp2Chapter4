package co.za.cput.ISP_Violate;

/**
 *
 */
public class Lecturer implements Person{

    public Boolean lectures()
    {
        return true;
    }

    public Boolean studies()
    {
        return false;
    }
}
