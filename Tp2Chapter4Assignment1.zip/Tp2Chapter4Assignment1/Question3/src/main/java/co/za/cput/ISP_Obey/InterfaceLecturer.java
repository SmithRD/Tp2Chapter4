package co.za.cput.ISP_Obey;

/**
 *
 */
public interface InterfaceLecturer {
    Boolean teaches();
}
