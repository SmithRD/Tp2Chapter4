package co.za.cput.DIP_Violate;

/**
 *
 */
public class Car {

    public String type()
    {
        return "Sedan";
    }

    public String make()
    {
        return "BMW";
    }


}
