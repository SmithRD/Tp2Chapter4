package co.za.cput.PLK_Violate;

/**
 *
 */
public class PreviousHome {
    private int number;

    PreviousHome(int nm)
    {
        number = nm;
    }

    int getNumber()
    {
        return number;
    }
}
