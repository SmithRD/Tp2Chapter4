package co.za.cput.PLK_Obey;

/**
 *
 */
public interface InterfacePerson {
    String getName();
    int getPreviousHomeNumber();
}
