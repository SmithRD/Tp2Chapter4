package co.za.cput.DIP_Obey;

/**
 *
 */
public interface Car {
    String getType();
    String getMake();
}
