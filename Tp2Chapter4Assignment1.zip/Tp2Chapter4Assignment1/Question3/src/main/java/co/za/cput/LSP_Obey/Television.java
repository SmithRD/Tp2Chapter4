package co.za.cput.LSP_Obey;

/**
 *
 */
public abstract class Television {
    public abstract boolean isHighDefinition();
    public abstract boolean is3DCompatible();
}
