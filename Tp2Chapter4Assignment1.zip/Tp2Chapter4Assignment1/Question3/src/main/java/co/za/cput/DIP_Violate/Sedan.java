package co.za.cput.DIP_Violate;

/**
 *
 */
public class Sedan {

    private Car car = new Car();

    public String type()
    {
        return car.type();
    }

    public String make()
    {
        return car.make();
    }
}
