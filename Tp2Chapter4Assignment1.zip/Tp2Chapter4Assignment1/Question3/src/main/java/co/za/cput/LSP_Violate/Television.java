package co.za.cput.LSP_Violate;

/**
 *
 */
public abstract class Television {
    public boolean isHighDefinition()
    {
        return true;
    }
    public abstract boolean is3DCompatible();
}
